package com.dailycodework.lakeSidehotel.exception;

public class InvalidBookingRequestException extends RuntimeException {


    public InvalidBookingRequestException(String message)
    {
        super(message);
    }

}
