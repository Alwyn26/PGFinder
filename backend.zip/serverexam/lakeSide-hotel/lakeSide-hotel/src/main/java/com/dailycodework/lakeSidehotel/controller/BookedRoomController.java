package com.dailycodework.lakeSidehotel.controller;

public class BookedRoomController {
}
