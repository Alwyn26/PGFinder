package com.dailycodework.lakeSidehotel.repository;

public interface BookedRoomRepository {
}
