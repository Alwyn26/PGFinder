package com.dailycodework.lakeSidehotel.response;
//
//public class RoomResponse {
//}
//package com.dailycodework.lakesidehotel.response;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.tomcat.util.codec.binary.Base64;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
public class RoomResponse {

    private Long id;
    private String roomType;
    private BigDecimal roomPrice;
    private boolean isBooked;
    private String photo;
    private String pgName;
    private Long pgId;
    private String location;
    private List<BookingResponse>bookings;


    public RoomResponse(Long id, String roomType, BigDecimal roomPrice,long pgId,String pgName,String location) {
        this.id = id;
        this.roomType = roomType;
        this.roomPrice = roomPrice;
        this.pgId=pgId;
        this.pgName=pgName;
        this.location=location;
    }

    public RoomResponse(Long id, String roomType, BigDecimal roomPrice, boolean isBooked,
                        byte[] photoBytes , long pgId,String pgName,String location) {  //List<BookingResponse> bookings
        this.id = id;
        this.roomType = roomType;
        this.roomPrice = roomPrice;
        this.isBooked = isBooked;
        this.photo = photoBytes != null ? Base64.encodeBase64String(photoBytes) : null;

        this.pgId=pgId;
        this.pgName=pgName;
        this.location=location;
        //this.bookings = bookings;
    }
}
