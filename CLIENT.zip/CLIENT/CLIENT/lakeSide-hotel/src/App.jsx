// import React from "react"
// import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
// import "/node_modules/bootstrap/dist/js/bootstrap.min.js"
// import AddRoom from "./components/room/AddRoom"
 
// function App() {
// 	return <>
// 	< AddRoom/>
// 	</>
		 
	
// }

// export default App
import React from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import AddRoom from "./components/room/AddRoom";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AddRoom />} />
        {/* Add other routes here */}
      </Routes>
    </Router>
  );
}

export default App;

